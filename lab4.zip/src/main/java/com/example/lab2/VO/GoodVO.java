package com.example.lab2.VO;

import com.example.lab2.PO.GoodPO;
import lombok.Data;
/**
 * @author GXC
 */
@Data
public class GoodVO {

    private Long id;

    private String name;

    private Long brandId;

    private Long categoryId;

    private Long freightId;

    private Long shopId;


    private String goodsSn;

    private String detail;
    private String imageUrl;
    private Byte disabled;

    public GoodVO(GoodPO goodPO) {
        this.id = goodPO.getId();
        this.name = goodPO.getName();
        this.brandId = goodPO.getBrandId();
        this.categoryId = goodPO.getCategoryId();
        this.freightId = goodPO.getFreightId();
        this.shopId = goodPO.getShopId();
        this.goodsSn = goodPO.getGoodsSn();
        this.detail = goodPO.getDetail();
        this.imageUrl = goodPO.getImageUrl();
        this.disabled = goodPO.getDisabled();
    }

    public GoodVO() {
    }
}