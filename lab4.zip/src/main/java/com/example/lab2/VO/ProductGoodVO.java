package com.example.lab2.VO;

import com.example.lab2.PO.GoodPO;
import com.example.lab2.PO.ProductPO;
import lombok.Data;

import java.io.Serializable;
/**
 * @author GXC
 */
@Data
public class ProductGoodVO implements Serializable {
    private Long id;
    private String name;
    private String productSn;
    private String detail;
    private String imageUrl;
    private Integer originalPrice;
    private Integer weight;
    private GoodVO good;

    public ProductGoodVO(ProductPO productPO,GoodPO goodPO) {
        id=productPO.getId();
        name=productPO.getName();
        productSn=productPO.getProductSn();
        detail=productPO.getDetail();
        imageUrl=productPO.getImageUrl();
        originalPrice=productPO.getOriginalPrice();
        weight=productPO.getWeight();
        good=new GoodVO(goodPO);
    }

    public ProductGoodVO(Long id, String name, String productSn, String detail, String imageUrl, Integer originalPrice, Integer weight, GoodVO good) {
        this.id = id;
        this.name = name;
        this.productSn = productSn;
        this.detail = detail;
        this.imageUrl = imageUrl;
        this.originalPrice = originalPrice;
        this.weight = weight;
        this.good = good;
    }

    public ProductGoodVO() {
    }
}
