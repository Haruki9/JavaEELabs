package com.example.lab2.controller;

import com.example.lab2.PO.GoodPO;
import com.example.lab2.PO.ProductPO;
import com.example.lab2.VO.ProductGoodVO;
import com.example.lab2.common.ReturnObject;
import com.example.lab2.mapper.GoodPOMapper;
import com.example.lab2.mapper.ProductPOMapper;
import com.example.lab2.util.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;

/**
 * @author GXC
 */
@RestController
public class order {
    @Autowired
    private GoodPOMapper goodPOMapper;
    @Autowired
    private ProductPOMapper productPOMapper;
    @Autowired
    private RedisUtil redisUtil;

    /**
     * 使用redis的版本
     * @param id
     * @return
     */
    @GetMapping("/pruducts/{id}")
    public Object getPruduct(@PathVariable("id") Long id){
        ReturnObject returnObject=null;
        redisUtil.get("productid"+id);
        ProductGoodVO productGoodVO=null;
        if(productGoodVO==null){
            ProductPO productPO=productPOMapper.selectByPrimaryKey(id);
            Long goodid=productPO.getGoodsId();
            GoodPO goodPO=goodPOMapper.selectByPrimaryKey(goodid);
            productGoodVO=new ProductGoodVO(productPO,goodPO);
            redisUtil.set("productid"+id, productGoodVO,-1);
//            System.out.println((ProductGoodVO)redisUtil.get("productid"+id));
        }else{
            redisUtil.del("productid"+id);
            redisUtil.set("productid"+id,productGoodVO,-1);
        }
        returnObject=new ReturnObject(productGoodVO);
        return returnObject;
    }

    /**
     * 没有redis的版本
     * @param id
     * @return
     */
    @GetMapping("/pruduct/{id}")
    public Object gotPruduct(@PathVariable("id") Long id){
        ReturnObject returnObject=null;
        ProductGoodVO productGoodVO=null;
        ProductPO productPO=productPOMapper.selectByPrimaryKey(id);
        Long goodid=productPO.getGoodsId();
        GoodPO goodPO=goodPOMapper.selectByPrimaryKey(goodid);
        productGoodVO=new ProductGoodVO(productPO,goodPO);
        returnObject=new ReturnObject(productGoodVO);
        return returnObject;
    }
}
